
with sector_data as (
 SELECT 1 AS Product_Id,'AAPL' AS Ticker,*, CAST("Date" AS DATE) AS trade_date FROM aapl
union  
select 2 as Product_Id,'AMZN' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM AMZN
union 
select 3 as Product_Id,'BAC' AS Ticker, *,CAST("Date" AS DATE) as trade_date FROM bac b 
union 
select 4 as Product_Id,'BK' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM bk
union  
select 5 as Product_Id,'C' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM c
union 
select 6 as Product_Id,'GOOGL' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM googl
union  
select 7 as Product_Id,'GS' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM gs
union 
select 8 as Product_Id,'JPM' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM jpm 
union 
select 9 as Product_Id,'META' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM meta
union  
select 10 as Product_Id,'MS' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM ms
union 
select 11 as Product_Id,'MSFT' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM msft
union  
select 12 as Product_Id,'NVDA' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM nvda 
union 
select 13 as Product_Id,'TSLA' AS Ticker,*,CAST("Date" AS DATE) as trade_date FROM tsla
)
SELECT
    Product_Id,Ticker,
    max(CASE 
        WHEN Product_Id IN (1,2,6,9,11,12,13) THEN 1
        WHEN Product_Id IN (3,4,5,7,8,10) THEN 2
    end) AS sector_id,
    max(case
    	when Product_Id IN (1,2,6,9,11,12,13) then 'technology'
    	WHEN Product_Id IN (3,4,5,7,8,10) then 'financial'
    end) as sector_name,
    max(case
    	when Product_Id in (1,11)then 1
    	when Product_Id in (6,9) then 2
    	when Product_Id in (2,13)then 3
    	when Product_Id in (12) then 4
    	when Product_Id in (3,4,5,7,8,9,10) then 5
    end) as sub_sector_id,
    max(case 
    	when Product_Id in (1,11)then 'technology consumer'
    	when Product_Id in (6,9) then 'communication services'
    	when Product_Id in (2,13)then 'consumer discretionary'
    	when Product_Id in (12) then 'semiconductor'
    	when Product_Id in (3,4,5,7,8,9,10) then 'banks'
    end) as sub_sector_name
FROM sector_data
group by product_id,Ticker