WITH sector_data AS (
    SELECT
        DENSE_RANK() OVER (ORDER BY sector_name, sub_sector_name) AS sector_rank,
        DENSE_RANK() OVER (PARTITION BY sector_name ORDER BY sub_sector_name) AS sub_sector_rank,
        index_id,
         CASE WHEN index_id = 1 THEN 'Nasdaq_100' WHEN index_id = 2 THEN 'S&P 500' END AS name_index,
        sector_id,
        sector_name,
        sub_sector_id,
        sub_sector_name
    FROM (
        SELECT 1 AS index_id, 1 AS sector_id, 'technology' AS sector_name, 1 AS sub_sector_id, 'technology consumer' AS sub_sector_name
        UNION
        SELECT 2 AS index_id, 2 AS sector_id, 'financial' AS sector_name, 5 AS sub_sector_id, 'banks' AS sub_sector_name
        UNION
        SELECT 1 AS index_id, 1 AS sector_id, 'technology' AS sector_name, 3 AS sub_sector_id, 'consumer discretionary' AS sub_sector_name
        UNION
        SELECT 1 AS index_id, 1 AS sector_id, 'technology' AS sector_name, 2 AS sub_sector_id, 'communication services' AS sub_sector_name
        UNION
        SELECT 1 AS index_id, 1 AS sector_id, 'technology' AS sector_name, 4 AS sub_sector_id, 'semiconductor' AS sub_sector_name
    ) AS sub_sector_data
)
SELECT
    index_id,
    name_index,
    sector_id,
    sector_name,
    sub_sector_id,
    sub_sector_name
FROM
    sector_data
UNION
SELECT
    2 AS index_id,
    name_index, 
    sector_id,
    sector_name,
    sub_sector_id,
    sub_sector_name
FROM
    sector_data