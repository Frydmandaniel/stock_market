-- models/fact/fact_stocks_simplified.sql

with all_stock_data as (
select  1 as Product_Id , *,  CAST("Date" AS DATE) as trade_date FROM aapl
union  
select 2 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM AMZN
union 
select  3 as Product_Id , *,CAST("Date" AS DATE) as trade_date FROM bac b 
union 
select  4 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM bk
union  
select 5 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM c
union 
select 6 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM googl
union  
select 7 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM gs
union 
select 8 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM jpm 
union 
select 9 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM meta
union  
select 10 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM ms
union 
select 11 as Product_Id,*,CAST("Date" AS DATE) as trade_date FROM msft
union  
select 12 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM nvda 
union 
select 13 as Product_Id ,*,CAST("Date" AS DATE) as trade_date FROM tsla
)
SELECT
    product_id,
    trade_date,
    "Open",
    "High",
    "Low",
    "Close",
    LAG("Close") OVER (ORDER BY product_id, trade_date) as close_yesterday,
    (("Close"/LAG("Close") OVER (ORDER BY product_id, trade_date))-1)*100  as daily_yield,
    "Volume",
    "Dividends",
    "Stock Splits"
FROM all_stock_data
where trade_date > '2021-01-03'