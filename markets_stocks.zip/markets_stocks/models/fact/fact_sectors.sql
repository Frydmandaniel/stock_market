with all_sectors as (
				select *,
				CAST("date" AS DATE) AS trade_date
				from sectors s ),
rel_sectors as(
				select *,
				case when ticker = 'XLK' then 1 
				 when ticker = 'XLC' then 2
				 when ticker = 'XLY' then 3
				 when ticker = 'XLF' then 5
				else 4 
				end as sector_id,
				CASE
            WHEN ticker = 'XLK' THEN 'Technology'
            WHEN ticker = 'XLC' THEN 'Communication Services'
            WHEN ticker = 'XLY' THEN 'Consumer Discretionary'
            WHEN ticker = 'XLF' THEN 'Financials'
            ELSE 'Semiconductors'
        END AS name_sector
				from all_sectors
				  WHERE
        trade_date >= '2021-01-03'
        and ticker in ('XLC', 'XLK','XLY','XLF')
        )
select sector_id, ticker,name_sector,trade_date,"close",
 LAG("close") OVER (ORDER BY sector, trade_date) as close_yesterday,
 (("close"/LAG("close") OVER (ORDER BY sector, trade_date))-1)*100  as daily_yield,
volume
from rel_sectors