 WITH index_invest AS (
    SELECT
        'nasdaq' AS index_type,
        *,
        CAST("date" AS DATE) AS trade_date
    FROM index_ndx
    UNION
    SELECT
        'sp_500' AS index_type,
        *,
        CAST("date" AS DATE) AS trade_date
    FROM index_spx
)
select
 CASE WHEN index_type = 'nasdaq' THEN 1
         WHEN index_type = 'sp_500' THEN 2
    END AS index_id,
    trade_date,
    "Open",
    "High",
    "Low",
    "Close",
     LAG("Close") OVER (ORDER BY index_type, trade_date) as close_yesterday,
     (("Close"/LAG("Close") OVER (ORDER BY index_type, trade_date))-1)  as daily_yield,
    index_value,
    "Volume"
FROM
    index_invest
   